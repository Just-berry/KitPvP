package org.example.kitpvplobby;
import org.bukkit.entity.Player;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

public class sendPlayer {

    //sendToServer sends the provided player to the provided target server
    public static void sendToServer(Player player, String targetServer)
    {
        //Setup the bytearray
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(byteArray);
        try{
            //Command: Connect "targetServer"
            out.writeUTF("Connect");
            out.writeUTF(targetServer);
        } catch (Exception e){
            e.printStackTrace();
        }
        //Send command message to BungeeCord
        player.sendPluginMessage(KitPvpLobby.getInstance(),"BungeeCord",byteArray.toByteArray());
    }
}
