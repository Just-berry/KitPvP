package org.example.kitpvp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import java.sql.*;
import java.util.ArrayList;

public class MySQLActions {

    private java.sql.Connection con = null;
    private final String url = KitPvP.getInstance().getDBConfig().getString("url");
    private final String user = KitPvP.getInstance().getDBConfig().getString("user");
    private final String password = KitPvP.getInstance().getDBConfig().getString("password");
    private final String table = KitPvP.getInstance().getDBConfig().getString("table");


    //Checks if player exists in the DB else creates a new player item
    public void checkPlayerData(Player player) {
        String sqlFindPlayer = String.format("SELECT * FROM %s WHERE player_uuid='%s'", table,player.getUniqueId().toString());
        ArrayList findPlayer = runSQL(sqlFindPlayer);
        player.sendMessage("Searching player database item");
        if(findPlayer.size() == 0){
            String sqlNewPlayer = String.format("INSERT INTO %s (player_uuid, kills, deaths) VALUES ('%s', '0', '0')",table,player.getUniqueId().toString());
            updateSQL(sqlNewPlayer);
            player.sendMessage("Player database item created");
        }
        else{
            player.sendMessage("Player database item exist");
        }
    }

    //Retrieve current kills using player uuid
    //Increment the kills
    //Update the table with the new data
    public void updatePlayerKills(Player player) {
        String sqlGetKills = String.format("SELECT kills FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList getKills = runSQL(sqlGetKills);
        String myString = getKills.get(0).toString();
        int kills = Integer.parseInt(myString);
        kills++;
        String sqlSetKills = String.format("UPDATE %s SET kills='%d' WHERE player_uuid = '%s'",table,kills,player.getUniqueId().toString());
        updateSQL(sqlSetKills);
    }

    //Retrieves current deaths using player uuid
    //Increments the deaths
    //Updates the table with the new data
    public void updatePlayerDeaths(Player player){

        String sqlGetDeaths = String.format("SELECT deaths FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList getDeaths = runSQL(sqlGetDeaths);

        String myString = getDeaths.get(0).toString();
        int deaths = Integer.parseInt(myString);
        deaths++;
        String sqlSetDeaths = String.format("UPDATE %s SET deaths='%d' WHERE player_uuid = '%s'",table,deaths,player.getUniqueId().toString());
        updateSQL(sqlSetDeaths);

    }

    //Retrieves data from the table
    public String getDeaths(Player player){
        String sqlGetData = String.format("SELECT * FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList playerData = runSQL(sqlGetData);
        String deaths = playerData.get(2).toString();
        return deaths;
    }

    //Return kills after running the needed sql query
    public String getKills(Player player){
        String sqlGetData = String.format("SELECT * FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList playerData = runSQL(sqlGetData);
        String kills = playerData.get(1).toString();
        return kills;
    }

    //Makes connections to the database and runs the provided SQL query
    //This is for SELECT queries
    public ArrayList runSQL(String sqlQuery){
        try {
            //setup connection to the DB
            con = DriverManager.getConnection(url, user, password);
            Statement st = (Statement) con.createStatement();

            //Execute the sql query on the connected DB
            ResultSet rs = st.executeQuery(sqlQuery);
            ResultSetMetaData meta = rs.getMetaData();
            int count = meta.getColumnCount();
            //create result list to store all the data retrieved from the query
            ArrayList<String> Results = new ArrayList<>(count);
            while (rs.next()) {
                int i = 1;
                while(i <= count) {
                    //cycle through all results and place them in the string list
                    Results.add(rs.getString(i++));
                }
            }
            con.close();
            //return the string list
            return Results;
        }

        catch (SQLException ex) {
            Bukkit.broadcastMessage(ex.toString());
            return null;
        }
    }

    //Runs the given sql query from the previous commands
    //This is for UPDATE queries
    public boolean updateSQL(String sqlQuery){
        try {
            //setup connection to the DB
            con = DriverManager.getConnection(url, user, password);
            Statement st = (Statement) con.createStatement();

            //Execute the sql query on the connected DB
            st.executeUpdate(sqlQuery);
            con.close();
            //return true on success
            return true;
        }

        catch (SQLException ex) {
            Bukkit.broadcastMessage(ex.toString());
            //return false on failure
            return false;
        }
    }
}



