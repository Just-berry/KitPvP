package org.example.kitpvplobby;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class EventListeners implements Listener{

    //Player click sign event checks if the player clicks a sign with the correct Text on it for Teleportation to the server stated in the text.
    //If the sign checks out, sendToServer(Player,Target) gets called
    @EventHandler
    public void onPlayerClickSign(PlayerInteractEvent event){
        Player p = event.getPlayer();
        //check for both different sign options
        try {
            if (event.getClickedBlock().getType() == Material.SIGN || event.getClickedBlock().getType() == Material.WALL_SIGN || event.getClickedBlock().getType() == Material.END_CRYSTAL) {
                //check right click event only
                if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                    Sign sign = (Sign) event.getClickedBlock().getState();
                    int i = 0;
                    //get server list from the main class and iterate through it
                    while (KitPvpLobby.getInstance().getServerList().size() > i) {
                        if (sign.getLine(1).equalsIgnoreCase(KitPvpLobby.getInstance().getServerList().get(i))) {
                            sendPlayer.sendToServer(p, KitPvpLobby.getInstance().getServerList().get(i));
                            sign.update();
                            return;
                        } else {
                            i++;
                        }
                    }
                }
            }
        }
        catch (NullPointerException ex){

        }
    }

    //Block place event checks for gold blocks. The placement of an Gold block sets the spawn location on that location
    @EventHandler
    public void BlockPlaceEvent​(BlockPlaceEvent event){
        Block block = event.getBlock();
        if(block.getType() == Material.GOLD_BLOCK){
            event.getPlayer().getWorld().setSpawnLocation(block.getLocation().add(0,1,0));
            event.getPlayer().sendMessage("New spawn location set");
        }
    }

    //Each time a player joins the lobby, the server list gets updated. dirty working solution for this current situation
    //Players gets teleported to the spawn point and the inventory of the player gets cleared
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {

        KitPvpLobby.getInstance().fetchServers();
        ScoreBoardPlayer score = new ScoreBoardPlayer();
        score.setScoreBoard(event.getPlayer());
        event.getPlayer().teleport(event.getPlayer().getWorld().getSpawnLocation());
        event.getPlayer().getInventory().clear();
    }

}
