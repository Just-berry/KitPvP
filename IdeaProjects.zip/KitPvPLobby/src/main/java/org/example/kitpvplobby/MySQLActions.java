package org.example.kitpvplobby;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.sql.*;
import java.util.ArrayList;

public class MySQLActions {

    private java.sql.Connection con = null;
    private final String url = KitPvpLobby.getInstance().getDBConfig().getString("url");
    private final String user = KitPvpLobby.getInstance().getDBConfig().getString("user");
    private final String password = KitPvpLobby.getInstance().getDBConfig().getString("password");
    private final String table = KitPvpLobby.getInstance().getDBConfig().getString("table");

    //Runs a sql query to retrieve the deaths from the player given and returns it
    public String getDeaths(Player player){
        String sqlGetData = String.format("SELECT * FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList playerData = runSQL(sqlGetData);
        //Column 2 is deaths
        String deaths = playerData.get(2).toString();
        return deaths;
    }

    //Runs a sql query to retrieve the kills from the player given and returns it
    public String getKills(Player player){
        String sqlGetData = String.format("SELECT * FROM %s WHERE player_uuid = '%s'",table,player.getUniqueId().toString());
        ArrayList playerData = runSQL(sqlGetData);
        //Column 1 is kills
        String kills = playerData.get(1).toString();
        return kills;
    }

    //Runs the given sql query from the previous commands
    public ArrayList runSQL(String sqlQuery){
        try {
            //setup connection to the DB
            con = DriverManager.getConnection(url, user, password);
            Statement st = (Statement) con.createStatement();

            //Execute the sql query on the connected DB
            ResultSet rs = st.executeQuery(sqlQuery);
            ResultSetMetaData meta = rs.getMetaData();
            int count = meta.getColumnCount();
            //create result list to store all the data retrieved from the query
            ArrayList<String> Results = new ArrayList<>(count);
            while (rs.next()) {
                int i = 1;
                while(i <= count) {
                    //cycle through all results and place them in the string list
                    Results.add(rs.getString(i++));
                }
            }
            con.close();
            //return the string list
            return Results;
        }

        catch (SQLException ex) {
            Bukkit.broadcastMessage(ex.toString());
            return null;
        }
    }
}
