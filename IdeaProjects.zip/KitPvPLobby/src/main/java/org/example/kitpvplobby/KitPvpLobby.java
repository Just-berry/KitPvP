package org.example.kitpvplobby;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public final class KitPvpLobby extends JavaPlugin implements PluginMessageListener {
    static KitPvpLobby instance;
    public List<String> serverList = new ArrayList<String>();

    private File customConfigFile;
    private FileConfiguration DBConfig;

    //Return DBConfig file defined up here
    public FileConfiguration getDBConfig() {
        return this.DBConfig;
    }

    public KitPvpLobby (){
        super();
        instance = this;

    }

    //Return this instance
    public static KitPvpLobby getInstance() {
        return instance;
    }

    //Return serverList
    public List<String> getServerList(){
        return serverList;
    }


    @Override
    public void onEnable()
    {
        //Register BungeeCord as outgoing target for plugin messages
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");

        //Register Eventlisteners class
        getServer().getPluginManager().registerEvents(new EventListeners(), this);

        //Register Incoming messages from bungeecord
        getServer().getMessenger().registerIncomingPluginChannel(this,"BungeeCord",this);

        //Check if exist or create DBCOnfig file
        createDBConfig();
    }

    //region bungee communication
    public void fetchServers() {
        getInstance().getServer().getScheduler().runTaskAsynchronously(this, new Runnable() {
            @Override
            public void run() {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                DataOutputStream out = new DataOutputStream(b);
                try {
                    out.writeUTF("GetServers");
                    out.flush();
                    b.flush();
                    getServer().sendPluginMessage(KitPvpLobby.getInstance(), "BungeeCord", b.toByteArray());
                    out.close();
                    b.close();
                } catch (Exception ex) {
                    // Error
                    ex.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onPluginMessageReceived(String channel,Player player, byte[] message) {
        if (!channel.equals("BungeeCord")) return;
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));

        try {
            String subchannel = in.readUTF();
            if (subchannel.equals("GetServers")) {
                String[] servers = in.readUTF().split(", ");
                serverList.clear();
                for(String server: servers){
                    serverList.add(server);
                }
            }
        } catch (Exception e) {
            // Error
        }
    }
    //endregion

    //Create custom config file containing the connection string to the database
    //This so Admins can configure their own connection
    private void createDBConfig() {
        customConfigFile = new File(getDataFolder(), "DBConfig.yml");
        if (!customConfigFile.exists()) {
            customConfigFile.getParentFile().mkdirs();
            saveResource("DBConfig.yml", false);
        }

        DBConfig= new YamlConfiguration();
        try {
            DBConfig.load(customConfigFile);
        } catch (IOException | InvalidConfigurationException e) {
            e.printStackTrace();
        }
    }

}
